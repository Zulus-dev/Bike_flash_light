# Умный габарит-поворотник-стоп-сигнал (ESP-IDF)

Редакция **2.6** — ESP-IDF + PlatformIO + GL5528.

## Железо
- ESP32-C3 SuperMini
- MPU-6050 (SDA=GPIO9, SCL=GPIO10)
- ULN2003A: LED ×4 + лазер + зуммер
- Фоторезистор GL5528 на GPIO0 (ADC1_CH0)
- Батарея ADC на GPIO1
- **LED_LEFT на GPIO2** (поворотник)
- **LED_STRIP на GPIO20** (перенесён с GPIO8 — strapping)
- **GPIO8 свободен** (критичен для USB download)
- POWER_HOLD на GPIO21
- Кнопка режимов GPIO6

## Прошивка

```bash
pio run -t upload
pio device monitor
```

GPIO8 не нагружен ULN → прошивка по USB без снятия ULN2003A.

## Кнопка SW_MODE
| Удержание | Действие |
|-----------|----------|
| < 1 с | Обычный ↔ Аварийка |
| 2–4 с | Выключение |
| 4–8 с | Охрана |
| ≥ 8 с | WiFi SoftAP |

## WiFi
- SSID: `BikeLight_AP` / `12345678`
- `http://192.168.4.1`

## Структура src/
```
main.c, config.c, led_control.c, buzzer.c,
motion_sensor.c, button.c, effects.c, state_machine.c,
wifi_web.c, battery.c, ldr.c, adc1_shared.c
```
